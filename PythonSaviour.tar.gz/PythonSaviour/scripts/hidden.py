#!/usr/bin/python2


import os

for root,dirs,files in os.walk('/home/project2'):
	for i in dirs:
		if(i[0] == "."):
			print i, 'Directory'


	for j in files:
		if (j[0] == "."):
			print j, 'File'


