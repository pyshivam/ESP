import os


while True:

	f = raw_input("Enter file name: ")

	choice = int(raw_input("1.Find file path\n2.Delete a file\n3. Exit\nEnter your choice: "))
	if(choice == 1):
		path = os.path.abspath(f)
		print path

	elif choice == 2:
		if os.path.exists(f):
			os.remove(os.path.abspath(f)) 
			print "File %s successfully deleted" % f
		else:
			print "File not found."

	choice = int(raw_input("1.Find file path\n2.Delete a file\n3. Exit\nEnter your choice: "))

	if choice == 3:
		break
	

